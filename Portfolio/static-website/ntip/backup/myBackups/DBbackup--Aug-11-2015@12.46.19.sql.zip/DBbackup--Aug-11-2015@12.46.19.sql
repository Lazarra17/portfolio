--
-- Database : ntips
--
-- --------------------------------------------------
-- ---------------------------------------------------
SET AUTOCOMMIT = 0 ;
SET FOREIGN_KEY_CHECKS=0 ;
--
-- Tabel structure for table `admin`
--
DROP TABLE  IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `fname` varchar(30) NOT NULL,
  `mname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `address` varchar(30) NOT NULL,
  `gender` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `admin`  VALUES ( "1","admin@yahoo.com","admin","admin","nis","trator","Sta. Mesa Manila","male");


--
-- Tabel structure for table `attendance`
--
DROP TABLE  IF EXISTS `attendance`;
CREATE TABLE `attendance` (
  `attendance_id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` varchar(255) NOT NULL,
  `emp_name` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `week` varchar(255) NOT NULL,
  `in_am` varchar(255) NOT NULL,
  `out_am` varchar(255) NOT NULL,
  `in_pm` varchar(255) NOT NULL,
  `out_pm` varchar(255) NOT NULL,
  `in_overtime` varchar(255) NOT NULL,
  `out_overtime` varchar(255) NOT NULL,
  PRIMARY KEY (`attendance_id`),
  UNIQUE KEY `attendance_id` (`attendance_id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=latin1;

INSERT INTO `attendance`  VALUES ( "1","27","Anna Dee HR","2015-07-01","WED","08:00","12:00","12:54","17:00"," "," ");
INSERT INTO `attendance`  VALUES ( "2","27","Anna Dee HR","2015-07-16","THU","08:00","12:00","12:54","17:00"," "," ");
INSERT INTO `attendance`  VALUES ( "3","27","Anna Dee HR","2015-07-02","THU","08:00","12:00","12:54","17:00"," "," ");
INSERT INTO `attendance`  VALUES ( "4","27","Anna Dee HR","2015-07-17","FRI"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "5","27","Anna Dee HR","2015-07-03","FRI","08:00","12:00","12:54","17:00"," "," ");
INSERT INTO `attendance`  VALUES ( "6","27","Anna Dee HR","2015-07-18","SAT"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "7","27","Anna Dee HR","2015-07-04","SAT","08:00","12:00","12:54","17:00"," "," ");
INSERT INTO `attendance`  VALUES ( "8","27","Anna Dee HR","2015-07-19","SUN","Rest ","","","","","");
INSERT INTO `attendance`  VALUES ( "9","27","Anna Dee HR","2015-07-05","SUN","Rest ","","","","","");
INSERT INTO `attendance`  VALUES ( "10","27","Anna Dee HR","2015-07-20","MON"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "11","27","Anna Dee HR","2015-07-06","MON","08:00","12:00","12:54","17:00"," "," ");
INSERT INTO `attendance`  VALUES ( "12","27","Anna Dee HR","2015-07-21","TUE"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "13","27","Anna Dee HR","2015-07-07","TUE","08:00","12:00","12:54","17:00"," "," ");
INSERT INTO `attendance`  VALUES ( "14","27","Anna Dee HR","2015-07-22","WED"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "15","27","Anna Dee HR","2015-07-08","WED","08:00","12:00","12:54","17:00"," "," ");
INSERT INTO `attendance`  VALUES ( "16","27","Anna Dee HR","2015-07-23","THU"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "17","27","Anna Dee HR","2015-07-09","THU","08:00","12:00","12:54","17:00"," "," ");
INSERT INTO `attendance`  VALUES ( "18","27","Anna Dee HR","2015-07-24","FRI"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "19","27","Anna Dee HR","2015-07-10","FRI","08:00","12:00","12:54","17:00"," "," ");
INSERT INTO `attendance`  VALUES ( "20","27","Anna Dee HR","2015-07-25","SAT"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "21","27","Anna Dee HR","2015-07-11","SAT","08:00","12:00","12:54","17:00"," "," ");
INSERT INTO `attendance`  VALUES ( "22","27","Anna Dee HR","2015-07-26","SUN","Rest ","","","","","");
INSERT INTO `attendance`  VALUES ( "23","27","Anna Dee HR","2015-07-12","SUN","Rest ","","","","","");
INSERT INTO `attendance`  VALUES ( "24","27","Anna Dee HR","2015-07-27","MON"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "25","27","Anna Dee HR","2015-07-13","MON","08:00","12:00","12:54","17:00"," "," ");
INSERT INTO `attendance`  VALUES ( "26","27","Anna Dee HR","2015-07-28","TUE"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "27","27","Anna Dee HR","2015-07-14","TUE","08:00","12:00","12:54","17:00"," "," ");
INSERT INTO `attendance`  VALUES ( "28","27","Anna Dee HR","2015-07-29","WED"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "29","27","Anna Dee HR","2015-07-15","WED","08:00","12:00","12:54","17:00"," "," ");
INSERT INTO `attendance`  VALUES ( "30","27","Anna Dee HR","2015-07-30","THU"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "31","28","Chad Lazarra","2015-07-01","WED","08:00","12:00","12:54","17:00"," "," ");
INSERT INTO `attendance`  VALUES ( "32","28","Chad Lazarra","2015-07-16","THU"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "33","28","Chad Lazarra","2015-07-02","THU"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "34","28","Chad Lazarra","2015-07-17","FRI"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "35","28","Chad Lazarra","2015-07-03","FRI"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "36","28","Chad Lazarra","2015-07-18","SAT"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "37","28","Chad Lazarra","2015-07-04","SAT"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "38","28","Chad Lazarra","2015-07-19","SUN","Rest ","","","","","");
INSERT INTO `attendance`  VALUES ( "39","28","Chad Lazarra","2015-07-05","SUN","Rest ","","","","","");
INSERT INTO `attendance`  VALUES ( "40","28","Chad Lazarra","2015-07-20","MON"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "41","28","Chad Lazarra","2015-07-06","MON"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "42","28","Chad Lazarra","2015-07-21","TUE"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "43","28","Chad Lazarra","2015-07-07","TUE"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "44","28","Chad Lazarra","2015-07-22","WED"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "45","28","Chad Lazarra","2015-07-08","WED"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "46","28","Chad Lazarra","2015-07-23","THU"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "47","28","Chad Lazarra","2015-07-09","THU"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "48","28","Chad Lazarra","2015-07-24","FRI"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "49","28","Chad Lazarra","2015-07-10","FRI"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "50","28","Chad Lazarra","2015-07-25","SAT"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "51","28","Chad Lazarra","2015-07-11","SAT"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "52","28","Chad Lazarra","2015-07-26","SUN","Rest ","","","","","");
INSERT INTO `attendance`  VALUES ( "53","28","Chad Lazarra","2015-07-12","SUN","Rest ","","","","","");
INSERT INTO `attendance`  VALUES ( "54","28","Chad Lazarra","2015-07-27","MON"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "55","28","Chad Lazarra","2015-07-13","MON"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "56","28","Chad Lazarra","2015-07-28","TUE"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "57","28","Chad Lazarra","2015-07-14","TUE"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "58","28","Chad Lazarra","2015-07-29","WED"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "59","28","Chad Lazarra","2015-07-15","WED"," "," "," "," "," "," ");
INSERT INTO `attendance`  VALUES ( "60","28","Chad Lazarra","2015-07-30","THU"," "," "," "," "," "," ");


--
-- Tabel structure for table `audit_trail`
--
DROP TABLE  IF EXISTS `audit_trail`;
CREATE TABLE `audit_trail` (
  `at_id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(30) NOT NULL,
  `department` varchar(50) NOT NULL,
  `activity` text NOT NULL,
  `ip_address` varchar(50) NOT NULL,
  `date_time_in` varchar(25) NOT NULL,
  `date_time_out` varchar(25) NOT NULL,
  PRIMARY KEY (`at_id`),
  UNIQUE KEY `at_id` (`at_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

INSERT INTO `audit_trail`  VALUES ( "4","Alvin Ellise","Human Resource","Time logged in: 08-10-2015 10:11:30pm+View.+Time logged out: 08-11-2015 10:00:28am","::1","08-10-2015 10:11:30pm","08-11-2015 10:00:28am");
INSERT INTO `audit_trail`  VALUES ( "5","Jessen Ricafort","Marketing","Time logged in: 08-11-2015 10:00:33am+View.+Generate orders list report+Generate customer list report+Generate orders list report+Generate product list report+Generate product list report+Generate product list report+Generate product list report","::1","08-11-2015 10:00:33am","");
INSERT INTO `audit_trail`  VALUES ( "6","Chad Lazarra","Production","Time logged in: 08-11-2015 11:41:37am+View.+Generate sales reports weekly report+Time logged out: 08-11-2015 11:43:16am","::1","08-11-2015 11:41:37am","08-11-2015 11:43:16am");
INSERT INTO `audit_trail`  VALUES ( "7","Jessen Ricafort","Marketing","Time logged in: 08-11-2015 11:47:50am+View.+Generate product list report+Time logged out: 08-11-2015 12:17:47pm","::1","08-11-2015 11:47:50am","08-11-2015 12:17:47pm");
INSERT INTO `audit_trail`  VALUES ( "8","Jessen Ricafort","Marketing","Time logged in: 08-11-2015 12:17:51pm+View.","::1","08-11-2015 12:17:51pm","");
INSERT INTO `audit_trail`  VALUES ( "9","Jessen Ricafort","Marketing","Time logged in: 08-11-2015 12:31:18pm+View.","::1","08-11-2015 12:31:18pm","");
INSERT INTO `audit_trail`  VALUES ( "10","Alvin Ellise","Human Resource","Time logged in: 08-11-2015 12:34:42pm+View.+Time logged out: 08-11-2015 12:34:52pm","::1","08-11-2015 12:34:41pm","08-11-2015 12:34:52pm");
INSERT INTO `audit_trail`  VALUES ( "11","Jessen Ricafort","Marketing","Time logged in: 08-11-2015 12:39:03pm+View.","::1","08-11-2015 12:39:02pm","");


--
-- Tabel structure for table `customer`
--
DROP TABLE  IF EXISTS `customer`;
CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(10) NOT NULL,
  `password` varchar(200) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL,
  `fname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `address` varchar(50) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `city` varchar(390) NOT NULL,
  `contact` varchar(12) NOT NULL,
  `date_created` date NOT NULL,
  `email` varchar(30) NOT NULL,
  `type` varchar(10) NOT NULL,
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

INSERT INTO `customer`  VALUES ( "3","nicoyah","5777b2c683b11b405a7613bba1fea713e35c41b9c736a8d66e5485606da6c1c3","Mark Jonald","Lazarra","Sta. Mesa Manila","Male","","0909","2015-06-22","shagilazarra@yahoo.com","Customer");
INSERT INTO `customer`  VALUES ( "4","Ianyah","23e60e56807eb22110068d2b6862bd4a5c8b7f8d495148160c6e71a522ac5ad5","Ian","Lazarra","Sta. MEsa","","","12121","2015-06-23","ianyah@yahoo.com","Customer");
INSERT INTO `customer`  VALUES ( "5","Royss","bf56e336bcca59ddc44142ccd70c9168e08c3227e8a7bf41cc7fdb55a182152d","Royss","Roys","Sta. MEsa","","","1212","2015-06-23","roys@yahoo.com","Customer");
INSERT INTO `customer`  VALUES ( "16","colontoy","cog3cSTWpgZsI","juan","colontoy","adffdsf","Male","","121212","2015-07-08","colontoy@yahoo.com","Customer");
INSERT INTO `customer`  VALUES ( "17","larry jone","24167f88af3dc8cad0197d2235bc2f90b91a5b9f15dc8336899bc623a393d883","Larry Joe","Magno","844 Rosarito St., Sampaloc, Manila","Male","","09056166941","2015-07-31","magnolarryjoe@yahoo.com","Customer");
INSERT INTO `customer`  VALUES ( "18","james","119c9ae6f9ca741bd0a76f87fba0b22cab5413187afb2906aa2875c38e213603","james","james","sta. catalina city","Male","","09191","2015-08-06","lazarra@yahoo.com","Customer");


--
-- Tabel structure for table `employee`
--
DROP TABLE  IF EXISTS `employee`;
CREATE TABLE `employee` (
  `emp_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `first_name` varchar(40) NOT NULL,
  `last_name` varchar(40) NOT NULL,
  `middle_name` varchar(40) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `birthday` date NOT NULL,
  `address` varchar(60) NOT NULL,
  `region` varchar(10) NOT NULL,
  `city` varchar(10) NOT NULL,
  `zip_code` varchar(6) NOT NULL,
  `contact` varchar(12) NOT NULL,
  `email` varchar(40) NOT NULL,
  `department` varchar(40) NOT NULL,
  `position` varchar(20) NOT NULL,
  `date_hired` date NOT NULL,
  `salary` varchar(6) NOT NULL,
  `status` varchar(40) NOT NULL,
  `date_added` date NOT NULL,
  `type` varchar(20) NOT NULL,
  PRIMARY KEY (`emp_id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

INSERT INTO `employee`  VALUES ( "27","annadee","157eb001277eafe0ca0c9a408f8a550cd4496d9105bef3c407d1a2e87e6c7ac3","Anna Dee","HR","Lazarra","Female","2015-01-16","Sta. Mesa Manila","Manila","Manila","1016","094874334368","anadf@yahoo.com","HR","Bookkeeper","2015-10-23","10000","Active","2015-06-23","employee");
INSERT INTO `employee`  VALUES ( "28","Lazarra17","19513fdc9da4fb72a4a05eb66917548d3c90ff94d5419e1f2363eea89dfee1dd","Chad","Lazarra","Nico","Male","2015-01-01","Sta. Mesa Manila","Manila","Manila","1016","09193156802","shagilazarra@yahoo.com","Marketing","Supervisor","2015-10-10","12000","Active","2015-08-09","employee");


--
-- Tabel structure for table `guest`
--
DROP TABLE  IF EXISTS `guest`;
CREATE TABLE `guest` (
  `guest_id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `city` varchar(50) NOT NULL,
  `address` varchar(255) NOT NULL,
  `contact` varchar(13) NOT NULL,
  `date_created` date NOT NULL,
  `type` varchar(20) NOT NULL,
  PRIMARY KEY (`guest_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `leave_message`
--
DROP TABLE  IF EXISTS `leave_message`;
CREATE TABLE `leave_message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `message` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `leave_report`
--
DROP TABLE  IF EXISTS `leave_report`;
CREATE TABLE `leave_report` (
  `leave_id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` varchar(20) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `department` varchar(50) NOT NULL,
  `position` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `leave_start` date NOT NULL,
  `leave_until` date NOT NULL,
  `reason` text NOT NULL,
  `rank` varchar(50) NOT NULL,
  `status` varchar(20) NOT NULL,
  `date_created` date NOT NULL,
  PRIMARY KEY (`leave_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `members`
--
DROP TABLE  IF EXISTS `members`;
CREATE TABLE `members` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `fname` varchar(30) NOT NULL,
  `mname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `address` varchar(30) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `department` varchar(40) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101113 DEFAULT CHARSET=latin1;

INSERT INTO `members`  VALUES ( "101112","asdfss","ss","fds","sadf","sdaf","sadf","sdaf","sadf");


--
-- Tabel structure for table `orders`
--
DROP TABLE  IF EXISTS `orders`;
CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(50) NOT NULL,
  `customer_address` varchar(255) NOT NULL,
  `particulars` varchar(50) NOT NULL,
  `items` varchar(3) NOT NULL,
  `unitprice` varchar(10) NOT NULL,
  `price` varchar(6) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contacts` varchar(50) NOT NULL,
  `order_date` date NOT NULL,
  `shipped_date` date NOT NULL,
  `status` varchar(10) NOT NULL,
  `methods` varchar(255) NOT NULL,
  `rank` varchar(10) NOT NULL,
  `receipt` varchar(20) NOT NULL,
  `state` varchar(20) NOT NULL,
  PRIMARY KEY (`order_id`),
  UNIQUE KEY `order_id` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15247702 DEFAULT CHARSET=latin1;

INSERT INTO `orders`  VALUES ( "15247700","Mark Jonald Lazarra","Sta. Mesa Manila","Tube Ice","10","120","1200","shagilazarra@yahoo.com","0909","2015-08-10","0000-00-00","Unverified","Cash on Delivery","new","None","");
INSERT INTO `orders`  VALUES ( "15247701","Mark Jonald Lazarra","Sta. Mesa Manila","Tube Ice","1","120","120","shagilazarra@yahoo.com","0909","2015-08-10","0000-00-00","Unverified","Cash on Delivery","new","None","");


--
-- Tabel structure for table `products`
--
DROP TABLE  IF EXISTS `products`;
CREATE TABLE `products` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_no` varchar(20) NOT NULL,
  `product_name` varchar(20) NOT NULL,
  `product_picture` varchar(30) NOT NULL,
  `unit` varchar(20) NOT NULL,
  `price` varchar(4) NOT NULL,
  `date_added` date NOT NULL,
  `date_updated` date NOT NULL,
  PRIMARY KEY (`product_id`),
  UNIQUE KEY `product_no` (`product_no`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `products`  VALUES ( "1","150001","Block Ice","images/block-ice.jpg","Block","100","0000-00-00","2015-08-11");
INSERT INTO `products`  VALUES ( "2","150002","Tube Ice","images/tube-ice.jpg","Sack","120","0000-00-00","0000-00-00");


--
-- Tabel structure for table `receipt`
--
DROP TABLE  IF EXISTS `receipt`;
CREATE TABLE `receipt` (
  `receipt_id` int(11) NOT NULL AUTO_INCREMENT,
  `OR_no` varchar(20) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `particulars` varchar(200) NOT NULL,
  `quantity` varchar(10) NOT NULL,
  `total_amount` varchar(10) NOT NULL,
  `tax` varchar(10) NOT NULL,
  `date_added` date NOT NULL,
  PRIMARY KEY (`receipt_id`),
  UNIQUE KEY `OR_no` (`OR_no`),
  UNIQUE KEY `receipt_id` (`receipt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `successful_deliveries`
--
DROP TABLE  IF EXISTS `successful_deliveries`;
CREATE TABLE `successful_deliveries` (
  `sd_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(50) NOT NULL,
  `address` varchar(1000) NOT NULL,
  `particulars` varchar(50) NOT NULL,
  `quantity` varchar(3) NOT NULL,
  `total_price` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `date_order` date NOT NULL,
  `date_shipped` date NOT NULL,
  PRIMARY KEY (`sd_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `updates`
--
DROP TABLE  IF EXISTS `updates`;
CREATE TABLE `updates` (
  `update_no` int(11) NOT NULL AUTO_INCREMENT,
  `order_no` varchar(25) NOT NULL,
  `date` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `email` varchar(50) NOT NULL,
  PRIMARY KEY (`update_no`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



--
-- Tabel structure for table `users`
--
DROP TABLE  IF EXISTS `users`;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_code` varchar(10) NOT NULL,
  `admin_no` varchar(15) NOT NULL,
  `admin_name` varchar(50) NOT NULL,
  `username` varchar(35) DEFAULT NULL,
  `password` varchar(200) DEFAULT NULL,
  `department` varchar(50) DEFAULT NULL,
  `gender` varchar(10) NOT NULL,
  `address` varchar(100) NOT NULL,
  `date_joined` date NOT NULL,
  `status` varchar(20) NOT NULL,
  `tries` int(1) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `users`  VALUES ( "1","1","15-00001","Alvin Ellise","admin","8c6976e5b5410415bde908bd4dee15dfb167a9c873fc4bb8a81f6f2ab448a918","Human Resource","","","0000-00-00","active","0");
INSERT INTO `users`  VALUES ( "2","2","15-00002","Jessen Ricafort","marketing","e2a530e251d3675034d23f5c5f87f54ec3182a088ba7d13350824794f8e6b76e","Marketing","","","0000-00-00","active","0");
INSERT INTO `users`  VALUES ( "3","3","15-00003","Chad Lazarra","delivery","b4af39d5b65a14849e885a9d65f0efe4f4e689989689c28c16cfcb3a6e78db5a","Production","","","0000-00-00","active","0");
INSERT INTO `users`  VALUES ( "4","4","15-00004","Sprokotong Colontoy","superadmin","186cf774c97b60a1c106ef718d10970a6a06e06bef89553d9ae65d938a886eae","superadmin","","","0000-00-00","active","0");
INSERT INTO `users`  VALUES ( "5","1","15-00005","Colontoy Colontoy","colontoy","24167f88af3dc8cad0197d2235bc2f90b91a5b9f15dc8336899bc623a393d883","Human Resources","Male","Sta. Mesa Manila","2015-08-07","active","0");


SET FOREIGN_KEY_CHECKS = 1 ; 
COMMIT ; 
SET AUTOCOMMIT = 1 ; 
